OK_FORMAT = True

test = {   'name': 'q6.1',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': '>>> assert len(q6b) == 1\n>>> assert isinstance(q6b, str)\n',
                                       'failure_message': 'Incorrect answer format. Make sure you only have the letter of your answer choice in quotes.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Correct answer format. Note that the actual test is hidden.'},
                                   {'code': ">>> assert get_hash(q6b.upper()) == '800618943025315f869e4e1f09471012'\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
