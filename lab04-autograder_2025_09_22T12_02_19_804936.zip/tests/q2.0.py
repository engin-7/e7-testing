OK_FORMAT = True

test = {   'name': 'q2.0',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q2_0)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': ">>> assert get_hash(Sum(14927421)) == '34173cb38f07f89ddbebc2ac9128303f'\n"
                                               ">>> assert get_hash(Sum(1371)) == 'c20ad4d76fe97759aa27a0c99bff6710'\n"
                                               ">>> assert get_hash(Sum(629)) == '70efdf2ec9b086079795c442636b55fb'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1.5},
                                   {   'code': ">>> assert get_hash(Sum(104927421)) == '34173cb38f07f89ddbebc2ac9128303f'\n"
                                               ">>> assert get_hash(Sum(13710)) == 'c20ad4d76fe97759aa27a0c99bff6710'\n"
                                               ">>> assert get_hash(Sum(60020090)) == '70efdf2ec9b086079795c442636b55fb'\n",
                                       'failure_message': 'What if n has 0?',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.75},
                                   {   'code': ">>> error_message = ['INVALID', 'INPUT']\n"
                                               ">>> assert get_hash(all([word in Sum(0.1).upper() for word in error_message])) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(all([word in Sum(10.1).upper() for word in error_message])) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(all([word in Sum(10.00000001).upper() for word in error_message])) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(all([word in Sum(10.9).upper() for word in error_message])) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(all([word in Sum(10.0).upper() for word in error_message])) == 'f827cf462f62848df37c5e1e94a4da74'\n",
                                       'failure_message': 'What if n is non-integer?',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': ">>> error_message = ['INVALID', 'INPUT']\n"
                                               ">>> assert get_hash(all([word in Sum(-1).upper() for word in error_message])) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(all([word in Sum(-99).upper() for word in error_message])) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(all([word in Sum(-0.01).upper() for word in error_message])) == 'f827cf462f62848df37c5e1e94a4da74'\n",
                                       'failure_message': 'What if n is negative?',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
