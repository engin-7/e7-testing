OK_FORMAT = True

test = {   'name': 'q4.1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(len(WinterHetchHetchy)) == 'eccbc87e4b5ce2fe28308fd9f2a7baf3'\n",
                                       'failure_message': 'Check length of selection.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.3},
                                   {   'code': ">>> assert get_hash(int(sum(WinterHetchHetchy))) == '50037bd6578a3e4db86ac430e190f7cb'\n",
                                       'failure_message': 'Check which column corresponds to Hetch Hetchy Reservoir.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5},
                                   {'code': ">>> assert get_hash(WinterHetchHetchy.astype(int)) == '7b67ebf4e3d0d34b2c62dba86b620e1b'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
