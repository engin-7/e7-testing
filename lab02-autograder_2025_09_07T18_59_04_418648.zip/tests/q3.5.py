OK_FORMAT = True

test = {   'name': 'q3.5',
    'points': 0.5,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(type_reservoir_data) == '30b39aca73d0815f5ca1a06af1412947'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
