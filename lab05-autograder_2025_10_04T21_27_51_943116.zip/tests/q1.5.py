OK_FORMAT = True

test = {   'name': 'q1.5',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q1_5)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': ">>> assert get_hash(round(finalFibRatio(29), 5)) == '57662aaff0603ba873d19444ae440a49'\n"
                                               ">>> assert get_hash(round(finalFibRatio(2), 5)) == 'e4c2e8edac362acab7123654b9e73432'\n"
                                               ">>> assert get_hash(round(finalFibRatio(3), 5)) == 'd1bd83a33f1a841ab7fda32449746cc4'\n"
                                               ">>> assert get_hash(round(finalFibRatio(4), 5)) == '6008647277c4454cecd97d33c069f0ca'\n"
                                               ">>> assert get_hash(round(finalFibRatio(5), 5)) == '95df9c10da10397475f9b1897410e091'\n",
                                       'failure_message': 'You should return r for valid input',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': ">>> assert get_hash(round(finalFibRatio(1), 5)) == 'a3d2de7675556553a5f08e4c88d2c228'\n",
                                       'failure_message': 'You should return np.nan for n = 1',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': ">>> assert get_hash(finalFibRatio(-1)) == 'dc9a0d67a31dae74f0ae340fc5ebbddb'\n"
                                               ">>> assert get_hash(finalFibRatio(0)) == 'dc9a0d67a31dae74f0ae340fc5ebbddb'\n"
                                               ">>> assert get_hash(finalFibRatio(12.4)) == 'dc9a0d67a31dae74f0ae340fc5ebbddb'\n",
                                       'failure_message': 'You should return -999 for non-positive or a fractional number',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': '>>> try:\n'
                                               '...     finalFibRatio(10 ** 5)\n'
                                               "...     assert get_hash(2) == 'c4ca4238a0b923820dcc509a6f75849b'\n"
                                               '... except RecursionError:\n'
                                               "...     assert get_hash(1) == 'c4ca4238a0b923820dcc509a6f75849b'\n",
                                       'failure_message': 'You should only handle the error raised by n = 1 and non-positive or a fractional number',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
