OK_FORMAT = True

test = {   'name': 'q1.3',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q1_3)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(round(midFibRatio(29), 5)) == '57662aaff0603ba873d19444ae440a49'\n"
                                               ">>> assert get_hash(round(midFibRatio(2), 5)) == 'e4c2e8edac362acab7123654b9e73432'\n"
                                               ">>> assert get_hash(round(midFibRatio(3), 5)) == 'd1bd83a33f1a841ab7fda32449746cc4'\n"
                                               ">>> assert get_hash(round(midFibRatio(4), 5)) == '6008647277c4454cecd97d33c069f0ca'\n"
                                               ">>> assert get_hash(round(midFibRatio(5), 5)) == '95df9c10da10397475f9b1897410e091'\n",
                                       'failure_message': 'You should return r for valid input',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': ">>> assert get_hash(round(midFibRatio(1), 5)) == 'a3d2de7675556553a5f08e4c88d2c228'\n",
                                       'failure_message': 'You should return np.nan for n = 1',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5},
                                   {   'code': '>>> try:\n'
                                               '...     midFibRatio(0)\n'
                                               "...     assert get_hash(2) == 'c4ca4238a0b923820dcc509a6f75849b'\n"
                                               '... except TypeError:\n'
                                               "...     assert get_hash(1) == 'c4ca4238a0b923820dcc509a6f75849b'\n",
                                       'failure_message': 'You should only handle the error raised by simpleFibRatio(1) and not all errors',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
