OK_FORMAT = True

test = {   'name': 'q1.2',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': '>>> assert len(q1_2) == 1\n>>> assert isinstance(q1_2, str)\n',
                                       'failure_message': 'Incorrect answer format. Make sure you only have the letter of your answer choice in quotes.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Correct answer format. Note that the actual test is hidden.'},
                                   {'code': ">>> assert get_hash(q1_2.upper()) == 'f623e75af30e62bbd73d6df5b50bb7b5'\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
