OK_FORMAT = True

test = {   'name': 'q2.7',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(q2_7.upper()) == '3a3ea00cfc35332cedf6e5e9a32e94da'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Correct! Collaboration is important and we encourage you to study together. However, it is important to keep in mind the limits to '
                                                          'collaboration. Any work you turn in must be 100% your own.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
