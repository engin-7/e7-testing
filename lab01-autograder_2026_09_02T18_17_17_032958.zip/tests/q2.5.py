OK_FORMAT = True

test = {   'name': 'q2.5',
    'points': 0.5,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(q2_5.upper()) == '0d61f8370cad1d412f80b84d143e1257'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
