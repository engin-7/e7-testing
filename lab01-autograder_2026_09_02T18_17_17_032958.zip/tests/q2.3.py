OK_FORMAT = True

test = {   'name': 'q2.3',
    'points': 0.25,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(q2_3.upper()) == 'd0a2813e3a668d6ffe354f6a29bf67fa'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
