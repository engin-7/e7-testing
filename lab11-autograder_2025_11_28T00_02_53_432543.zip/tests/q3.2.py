OK_FORMAT = True

test = {   'name': 'q3.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q3_2)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': '>>> t_span = [0, 5]\n'
                                               '>>> s0 = np.array([1, 0])\n'
                                               '>>> m = 1\n'
                                               '>>> c = 0.5\n'
                                               '>>> k = 16\n'
                                               '>>> n = 1000\n'
                                               '>>> ts, xs, vs = my_backward_euler(t_span, n, s0, m, c, k)\n'
                                               ">>> assert get_hash(len(ts)) == 'b8c37e33defde51cf91e1e03e51657da'\n"
                                               ">>> assert get_hash(len(xs)) == 'b8c37e33defde51cf91e1e03e51657da'\n"
                                               ">>> assert get_hash(len(vs)) == 'b8c37e33defde51cf91e1e03e51657da'\n",
                                       'failure_message': 'Check length of output arrays.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> t_span = [0, 5]\n'
                                               '>>> s0 = np.array([1, 0])\n'
                                               '>>> m = 1\n'
                                               '>>> c = 0.5\n'
                                               '>>> k = 16\n'
                                               '>>> n = 1000\n'
                                               '>>> ts, xs, vs = my_backward_euler(t_span, n, s0, m, c, k)\n'
                                               ">>> assert get_hash(np.round(np.sum(ts), decimals=8)) == '5049d9223570b92e9ef50eeed2f8b766'\n",
                                       'failure_message': 'Check values of output time array.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> t_span = [0, 5]\n'
                                               '>>> s0 = np.array([1, 0])\n'
                                               '>>> m = 1\n'
                                               '>>> c = 0.5\n'
                                               '>>> k = 16\n'
                                               '>>> n = 1000\n'
                                               '>>> ts, xs, vs = my_backward_euler(t_span, n, s0, m, c, k)\n'
                                               ">>> assert get_hash(np.round(np.sum(xs), decimals=8)) == 'dde4a0bed4a2b03b7d60fe0ada41504c'\n",
                                       'failure_message': 'Check values of output displacement array.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> t_span = [0, 5]\n'
                                               '>>> s0 = np.array([1, 0])\n'
                                               '>>> m = 1\n'
                                               '>>> c = 0.5\n'
                                               '>>> k = 16\n'
                                               '>>> n = 1000\n'
                                               '>>> ts, xs, vs = my_backward_euler(t_span, n, s0, m, c, k)\n'
                                               ">>> assert get_hash(np.round(np.sum(vs), decimals=8)) == '7f0f42a4f63f97eba3d4fda1a0fdb9ef'\n",
                                       'failure_message': 'Check values of output velocity array.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> t_span = [0, 5]\n'
                                               '>>> s0 = np.array([1, 0])\n'
                                               '>>> m = 1\n'
                                               '>>> c = 1\n'
                                               '>>> k = 12\n'
                                               '>>> n = 500\n'
                                               '>>> ts, xs, vs = my_backward_euler(t_span, n, s0, m, c, k)\n'
                                               ">>> assert get_hash(len(ts)) == '5b69b9cb83065d403869739ae7f0995e'\n"
                                               ">>> assert get_hash(len(xs)) == '5b69b9cb83065d403869739ae7f0995e'\n"
                                               ">>> assert get_hash(len(vs)) == '5b69b9cb83065d403869739ae7f0995e'\n"
                                               ">>> assert get_hash(np.round(np.sum(ts), decimals=10)) == 'fd81a7e6cafbae470a387dc89499e6e9'\n"
                                               ">>> assert get_hash(np.round(np.sum(xs), decimals=10)) == '90dbbc9eada746e202df1da7497af42d'\n"
                                               ">>> assert get_hash(np.round(np.sum(vs), decimals=10)) == '7d991b3f4893f2db0f159fe81259d4a5'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
