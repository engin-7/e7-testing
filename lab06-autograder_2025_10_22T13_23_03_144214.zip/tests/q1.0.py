OK_FORMAT = True

test = {   'name': 'q1.0',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q1_0)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(length) == 'f899139df5e1059396431415e770c6dd'\n",
                                       'failure_message': 'Check the bar length.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.1},
                                   {   'code': ">>> assert callable(u0) and u0.__name__ == '<lambda>'\n",
                                       'failure_message': 'Make sure it is a lambda function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.1},
                                   {   'code': ">>> assert get_hash(np.round(u0(0), decimals=2)) == '30565a8911a6bb487e3745c0ea3c8224'\n"
                                               ">>> assert get_hash(np.round(u0(10), decimals=2)) == 'bf9cba947baf9cc43f447e0e0fc7efce'\n"
                                               ">>> assert get_hash(np.round(u0(60), decimals=2)) == '9f7c34c89841d32c138e886829eb4154'\n"
                                               ">>> assert get_hash(np.round(u0(100), decimals=2)) == '30565a8911a6bb487e3745c0ea3c8224'\n"
                                               ">>> assert callable(u0) and u0.__name__ == '<lambda>'\n",
                                       'failure_message': 'Check your u0 function.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5},
                                   {   'code': '>>> x = np.linspace(0, 100)\n'
                                               ">>> assert get_hash(len(u0(x))) == 'c0c7c76d30bd3dcaefc96f40275bdc0a'\n"
                                               ">>> assert get_hash(np.round(np.sum(u0(x)), decimals=2)) == '82fd5432008dcbb742f92940ad26cd05'\n"
                                               ">>> assert callable(u0) and u0.__name__ == '<lambda>'\n",
                                       'failure_message': 'Make sure your u0 function works on array inputs.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.3}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
