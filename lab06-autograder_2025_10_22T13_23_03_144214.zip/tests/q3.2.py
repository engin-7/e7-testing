OK_FORMAT = True

test = {   'name': 'q3.2',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> q3_2 = np.loadtxt('resources/wind_mag.csv', delimiter=',')\n"
                                               ">>> assert get_hash(np.round(np.sum(q3_2), decimals=2)) == '872e27abbbc3735010e8d1f58ae6c465'\n",
                                       'failure_message': 'Check your write command and write location.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
